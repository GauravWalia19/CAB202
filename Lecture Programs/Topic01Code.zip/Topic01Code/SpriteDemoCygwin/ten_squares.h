/*
*	File:	ten_squares.h
*	Author: Lawrence Buckingham, Queensland University of Technology.
*	Date:	27 April 2015.
*
*	Declaration of the functions provided by the one_square "game".
*/

#ifndef __TEN_SQUAREs__
#define __TEN_SQUAREs__

void play_ten_squares( void );

#endif