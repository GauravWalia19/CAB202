/*
*	File:	blockhead.h
*	Author: Lawrence Buckingham, Queensland University of Technology.
*	Date:	28 April 2015.
*
*	Entry point for the sprite demo program.
*/


#ifndef __BLOCKHEAD__
#define __BLOCKHEAD__

void walk_the_walk( void );

#endif